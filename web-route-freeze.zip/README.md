# Api
Provides boilerplate code for creating a lightweight api framework. 

# Features
* Fully integrated JWT authorization
* Dedicated database class so you never have to write sql
* Complete error handling
* Administrative panel (coming soon)


