<?php
define("BASE_URL","/api/v1");
define("APP_KEY","F682109AA8743B44D01E721503568A9CC8DE4EAA9EA07BC35CC31A020BEA2679");
define("DB_HOST","localhost");
define("DB_PASS","");
define("DB","api");
define("DB_USER","root");


//validation messages