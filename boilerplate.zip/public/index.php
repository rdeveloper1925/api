<?php

use Pecee\SimpleRouter\SimpleRouter;
require_once "../vendor/autoload.php";
require_once "../app/Routes.php";
//require_once "../app/helpers.php";

SimpleRouter::start();
